<div class="row p-3">
<div class="col-md-4">
<?php if(session('error')): ?>

<script>
toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
                toastr.error("<?php echo e(session('error')); ?>");
</script>
       
    <?php endif; ?>
<?php if(session('success')): ?>

<script>
toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
                toastr.success("<?php echo e(session('success')); ?>");
</script>
       
    <?php endif; ?>

    <form action="<?php echo e(route('email.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <div class="form-field">
                <label for="email">Email</label>
                <input type="text" name="email" class="form-control" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <button type="submit" class="btn btn-primary"> Submit</button>
    </form>
    </div>

    <div class="col-md-8">
  
    <?php if($user_data->isEmpty()): ?>
    <p>No credentials found.</p>
<?php else: ?>
<table class="table table-bordered">


<thead>
    <th>#</th>
    <th>email</th>
    <th>password</th>
</thead>


<tbody>
<?php $__currentLoopData = $user_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>1</td>
        <td><?php echo e($data->email); ?></td>
        <td><?php echo e($data->password); ?></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php endif; ?>

</div>

</div><?php /**PATH C:\xampp\htdocs\o2\o2\resources\views/components/welcome.blade.php ENDPATH**/ ?>